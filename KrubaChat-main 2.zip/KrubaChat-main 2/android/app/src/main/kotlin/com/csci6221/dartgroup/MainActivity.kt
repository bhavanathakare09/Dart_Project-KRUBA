package com.csci6221.dartgroup

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
